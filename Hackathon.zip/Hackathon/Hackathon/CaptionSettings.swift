//
//  CaptionSettings.swift
//  Hackathon
//
//  Created by Hanbo Yu on 2021-01-16.
//

import SwiftUI

struct CaptionSettings: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct CaptionSettings_Previews: PreviewProvider {
    static var previews: some View {
        CaptionSettings()
    }
}
